<?php

namespace Symfony\Config\OverblogGraphql;

use Symfony\Component\Config\Loader\ParamConfigurator;
use Symfony\Component\Config\Definition\Exception\InvalidConfigurationException;

/**
 * This class is automatically generated to help in creating a config.
 */
class SecurityConfig 
{
    private $queryMaxDepth;
    private $queryMaxComplexity;
    private $enableIntrospection;
    private $handleCors;
    private $_usedProperties = [];

    /**
     * Disabled if equal to false.
     * @default 0
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function queryMaxDepth($value): static
    {
        $this->_usedProperties['queryMaxDepth'] = true;
        $this->queryMaxDepth = $value;

        return $this;
    }

    /**
     * Disabled if equal to false.
     * @default 0
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function queryMaxComplexity($value): static
    {
        $this->_usedProperties['queryMaxComplexity'] = true;
        $this->queryMaxComplexity = $value;

        return $this;
    }

    /**
     * @default true
     * @param ParamConfigurator|bool $value
     * @return $this
     */
    public function enableIntrospection($value): static
    {
        $this->_usedProperties['enableIntrospection'] = true;
        $this->enableIntrospection = $value;

        return $this;
    }

    /**
     * @default false
     * @param ParamConfigurator|bool $value
     * @return $this
     */
    public function handleCors($value): static
    {
        $this->_usedProperties['handleCors'] = true;
        $this->handleCors = $value;

        return $this;
    }

    public function __construct(array $value = [])
    {
        if (array_key_exists('query_max_depth', $value)) {
            $this->_usedProperties['queryMaxDepth'] = true;
            $this->queryMaxDepth = $value['query_max_depth'];
            unset($value['query_max_depth']);
        }

        if (array_key_exists('query_max_complexity', $value)) {
            $this->_usedProperties['queryMaxComplexity'] = true;
            $this->queryMaxComplexity = $value['query_max_complexity'];
            unset($value['query_max_complexity']);
        }

        if (array_key_exists('enable_introspection', $value)) {
            $this->_usedProperties['enableIntrospection'] = true;
            $this->enableIntrospection = $value['enable_introspection'];
            unset($value['enable_introspection']);
        }

        if (array_key_exists('handle_cors', $value)) {
            $this->_usedProperties['handleCors'] = true;
            $this->handleCors = $value['handle_cors'];
            unset($value['handle_cors']);
        }

        if ([] !== $value) {
            throw new InvalidConfigurationException(sprintf('The following keys are not supported by "%s": ', __CLASS__).implode(', ', array_keys($value)));
        }
    }

    public function toArray(): array
    {
        $output = [];
        if (isset($this->_usedProperties['queryMaxDepth'])) {
            $output['query_max_depth'] = $this->queryMaxDepth;
        }
        if (isset($this->_usedProperties['queryMaxComplexity'])) {
            $output['query_max_complexity'] = $this->queryMaxComplexity;
        }
        if (isset($this->_usedProperties['enableIntrospection'])) {
            $output['enable_introspection'] = $this->enableIntrospection;
        }
        if (isset($this->_usedProperties['handleCors'])) {
            $output['handle_cors'] = $this->handleCors;
        }

        return $output;
    }

}
