<?php

namespace Symfony\Config\OverblogGraphql;

use Symfony\Component\Config\Loader\ParamConfigurator;
use Symfony\Component\Config\Definition\Exception\InvalidConfigurationException;

/**
 * This class is automatically generated to help in creating a config.
 */
class ServicesConfig 
{
    private $executor;
    private $promiseAdapter;
    private $expressionLanguage;
    private $cacheExpressionLanguageParser;
    private $_usedProperties = [];

    /**
     * @default 'Overblog\\GraphQLBundle\\Executor\\Executor'
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function executor($value): static
    {
        $this->_usedProperties['executor'] = true;
        $this->executor = $value;

        return $this;
    }

    /**
     * @default 'GraphQL\\Executor\\Promise\\Adapter\\SyncPromiseAdapter'
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function promiseAdapter($value): static
    {
        $this->_usedProperties['promiseAdapter'] = true;
        $this->promiseAdapter = $value;

        return $this;
    }

    /**
     * @default 'Overblog\\GraphQLBundle\\ExpressionLanguage\\ExpressionLanguage'
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function expressionLanguage($value): static
    {
        $this->_usedProperties['expressionLanguage'] = true;
        $this->expressionLanguage = $value;

        return $this;
    }

    /**
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function cacheExpressionLanguageParser($value): static
    {
        $this->_usedProperties['cacheExpressionLanguageParser'] = true;
        $this->cacheExpressionLanguageParser = $value;

        return $this;
    }

    public function __construct(array $value = [])
    {
        if (array_key_exists('executor', $value)) {
            $this->_usedProperties['executor'] = true;
            $this->executor = $value['executor'];
            unset($value['executor']);
        }

        if (array_key_exists('promise_adapter', $value)) {
            $this->_usedProperties['promiseAdapter'] = true;
            $this->promiseAdapter = $value['promise_adapter'];
            unset($value['promise_adapter']);
        }

        if (array_key_exists('expression_language', $value)) {
            $this->_usedProperties['expressionLanguage'] = true;
            $this->expressionLanguage = $value['expression_language'];
            unset($value['expression_language']);
        }

        if (array_key_exists('cache_expression_language_parser', $value)) {
            $this->_usedProperties['cacheExpressionLanguageParser'] = true;
            $this->cacheExpressionLanguageParser = $value['cache_expression_language_parser'];
            unset($value['cache_expression_language_parser']);
        }

        if ([] !== $value) {
            throw new InvalidConfigurationException(sprintf('The following keys are not supported by "%s": ', __CLASS__).implode(', ', array_keys($value)));
        }
    }

    public function toArray(): array
    {
        $output = [];
        if (isset($this->_usedProperties['executor'])) {
            $output['executor'] = $this->executor;
        }
        if (isset($this->_usedProperties['promiseAdapter'])) {
            $output['promise_adapter'] = $this->promiseAdapter;
        }
        if (isset($this->_usedProperties['expressionLanguage'])) {
            $output['expression_language'] = $this->expressionLanguage;
        }
        if (isset($this->_usedProperties['cacheExpressionLanguageParser'])) {
            $output['cache_expression_language_parser'] = $this->cacheExpressionLanguageParser;
        }

        return $output;
    }

}
