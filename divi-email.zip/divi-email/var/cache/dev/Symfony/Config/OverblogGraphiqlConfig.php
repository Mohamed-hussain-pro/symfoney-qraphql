<?php

namespace Symfony\Config;

require_once __DIR__.\DIRECTORY_SEPARATOR.'OverblogGraphiql'.\DIRECTORY_SEPARATOR.'JavascriptLibrariesConfig.php';

use Symfony\Component\Config\Loader\ParamConfigurator;
use Symfony\Component\Config\Definition\Exception\InvalidConfigurationException;

/**
 * This class is automatically generated to help in creating a config.
 */
class OverblogGraphiqlConfig implements \Symfony\Component\Config\Builder\ConfigBuilderInterface
{
    private $endpointResolver;
    private $template;
    private $javascriptLibraries;
    private $_usedProperties = [];

    /**
     * @default 'Overblog\\GraphiQLBundle\\Config\\GraphQLEndpoint\\Helpers\\OverblogGraphQLBundleEndpointResolver'
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function endpointResolver($value): static
    {
        $this->_usedProperties['endpointResolver'] = true;
        $this->endpointResolver = $value;

        return $this;
    }

    /**
     * In case you need it's possible to replace GraphiQL twig template
     * @default '@OverblogGraphiQL/GraphiQL/index.html.twig'
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function template($value): static
    {
        $this->_usedProperties['template'] = true;
        $this->template = $value;

        return $this;
    }

    /**
     * @default {"graphiql":"0.11","react":"15.6","fetch":"2.0"}
    */
    public function javascriptLibraries(array $value = []): \Symfony\Config\OverblogGraphiql\JavascriptLibrariesConfig
    {
        if (null === $this->javascriptLibraries) {
            $this->_usedProperties['javascriptLibraries'] = true;
            $this->javascriptLibraries = new \Symfony\Config\OverblogGraphiql\JavascriptLibrariesConfig($value);
        } elseif (0 < \func_num_args()) {
            throw new InvalidConfigurationException('The node created by "javascriptLibraries()" has already been initialized. You cannot pass values the second time you call javascriptLibraries().');
        }

        return $this->javascriptLibraries;
    }

    public function getExtensionAlias(): string
    {
        return 'overblog_graphiql';
    }

    public function __construct(array $value = [])
    {
        if (array_key_exists('endpoint_resolver', $value)) {
            $this->_usedProperties['endpointResolver'] = true;
            $this->endpointResolver = $value['endpoint_resolver'];
            unset($value['endpoint_resolver']);
        }

        if (array_key_exists('template', $value)) {
            $this->_usedProperties['template'] = true;
            $this->template = $value['template'];
            unset($value['template']);
        }

        if (array_key_exists('javascript_libraries', $value)) {
            $this->_usedProperties['javascriptLibraries'] = true;
            $this->javascriptLibraries = new \Symfony\Config\OverblogGraphiql\JavascriptLibrariesConfig($value['javascript_libraries']);
            unset($value['javascript_libraries']);
        }

        if ([] !== $value) {
            throw new InvalidConfigurationException(sprintf('The following keys are not supported by "%s": ', __CLASS__).implode(', ', array_keys($value)));
        }
    }

    public function toArray(): array
    {
        $output = [];
        if (isset($this->_usedProperties['endpointResolver'])) {
            $output['endpoint_resolver'] = $this->endpointResolver;
        }
        if (isset($this->_usedProperties['template'])) {
            $output['template'] = $this->template;
        }
        if (isset($this->_usedProperties['javascriptLibraries'])) {
            $output['javascript_libraries'] = $this->javascriptLibraries->toArray();
        }

        return $output;
    }

}
