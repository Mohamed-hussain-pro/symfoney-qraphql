<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/graphiql' => [[['_route' => 'overblog_graphiql_endpoint', '_controller' => 'Overblog\\GraphiQLBundle\\Controller\\GraphiQLController::indexAction'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'overblog_graphql_endpoint', '_controller' => 'Overblog\\GraphQLBundle\\Controller\\GraphController::endpointAction', '_format' => 'json'], null, null, null, false, false, null]],
        '/batch' => [[['_route' => 'overblog_graphql_batch_endpoint', '_controller' => 'Overblog\\GraphQLBundle\\Controller\\GraphController::batchEndpointAction', '_format' => 'json'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/graph(?'
                    .'|iql/([^/]++)(*:28)'
                    .'|ql/(?'
                        .'|([^/]+)(*:48)'
                        .'|([^/]+)/batch(*:68)'
                    .')'
                .')'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:105)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        28 => [[['_route' => 'overblog_graphiql_endpoint_multiple', '_controller' => 'Overblog\\GraphiQLBundle\\Controller\\GraphiQLController::indexAction'], ['schemaName'], null, null, false, true, null]],
        48 => [[['_route' => 'overblog_graphql_multiple_endpoint', '_controller' => 'Overblog\\GraphQLBundle\\Controller\\GraphController::endpointAction', '_format' => 'json'], ['schemaName'], null, null, false, true, null]],
        68 => [[['_route' => 'overblog_graphql_batch_multiple_endpoint', '_controller' => 'Overblog\\GraphQLBundle\\Controller\\GraphController::batchEndpointAction', '_format' => 'json'], ['schemaName'], null, null, false, false, null]],
        105 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
