<?php

namespace Symfony\Config;

require_once __DIR__.\DIRECTORY_SEPARATOR.'OverblogGraphql'.\DIRECTORY_SEPARATOR.'DefinitionsConfig.php';
require_once __DIR__.\DIRECTORY_SEPARATOR.'OverblogGraphql'.\DIRECTORY_SEPARATOR.'ErrorsHandlerConfig.php';
require_once __DIR__.\DIRECTORY_SEPARATOR.'OverblogGraphql'.\DIRECTORY_SEPARATOR.'ServicesConfig.php';
require_once __DIR__.\DIRECTORY_SEPARATOR.'OverblogGraphql'.\DIRECTORY_SEPARATOR.'SecurityConfig.php';
require_once __DIR__.\DIRECTORY_SEPARATOR.'OverblogGraphql'.\DIRECTORY_SEPARATOR.'DoctrineConfig.php';
require_once __DIR__.\DIRECTORY_SEPARATOR.'OverblogGraphql'.\DIRECTORY_SEPARATOR.'ProfilerConfig.php';

use Symfony\Component\Config\Loader\ParamConfigurator;
use Symfony\Component\Config\Definition\Exception\InvalidConfigurationException;

/**
 * This class is automatically generated to help in creating a config.
 */
class OverblogGraphqlConfig implements \Symfony\Component\Config\Builder\ConfigBuilderInterface
{
    private $batchingMethod;
    private $definitions;
    private $errorsHandler;
    private $services;
    private $security;
    private $doctrine;
    private $profiler;
    private $_usedProperties = [];

    /**
     * @default 'relay'
     * @param ParamConfigurator|'relay'|'apollo' $value
     * @return $this
     */
    public function batchingMethod($value): static
    {
        $this->_usedProperties['batchingMethod'] = true;
        $this->batchingMethod = $value;

        return $this;
    }

    /**
     * @default {"argument_class":"Overblog\\GraphQLBundle\\Definition\\Argument","use_experimental_executor":false,"default_field_resolver":"Overblog\\GraphQLBundle\\Resolver\\FieldResolver","class_namespace":"Overblog\\GraphQLBundle\\__DEFINITIONS__","cache_dir":null,"cache_dir_permissions":null,"use_classloader_listener":true,"auto_compile":true,"show_debug_info":false,"config_validation":true,"schema":[]}
    */
    public function definitions(array $value = []): \Symfony\Config\OverblogGraphql\DefinitionsConfig
    {
        if (null === $this->definitions) {
            $this->_usedProperties['definitions'] = true;
            $this->definitions = new \Symfony\Config\OverblogGraphql\DefinitionsConfig($value);
        } elseif (0 < \func_num_args()) {
            throw new InvalidConfigurationException('The node created by "definitions()" has already been initialized. You cannot pass values the second time you call definitions().');
        }

        return $this->definitions;
    }

    /**
     * @default {"enabled":true,"internal_error_message":"Internal server Error","rethrow_internal_exceptions":false,"debug":true,"log":true,"logger_service":"logger","map_exceptions_to_parent":false,"exceptions":{"warnings":[],"errors":[]}}
    */
    public function errorsHandler(array $value = []): \Symfony\Config\OverblogGraphql\ErrorsHandlerConfig
    {
        if (null === $this->errorsHandler) {
            $this->_usedProperties['errorsHandler'] = true;
            $this->errorsHandler = new \Symfony\Config\OverblogGraphql\ErrorsHandlerConfig($value);
        } elseif (0 < \func_num_args()) {
            throw new InvalidConfigurationException('The node created by "errorsHandler()" has already been initialized. You cannot pass values the second time you call errorsHandler().');
        }

        return $this->errorsHandler;
    }

    /**
     * @default {"executor":"Overblog\\GraphQLBundle\\Executor\\Executor","promise_adapter":"GraphQL\\Executor\\Promise\\Adapter\\SyncPromiseAdapter","expression_language":"Overblog\\GraphQLBundle\\ExpressionLanguage\\ExpressionLanguage"}
    */
    public function services(array $value = []): \Symfony\Config\OverblogGraphql\ServicesConfig
    {
        if (null === $this->services) {
            $this->_usedProperties['services'] = true;
            $this->services = new \Symfony\Config\OverblogGraphql\ServicesConfig($value);
        } elseif (0 < \func_num_args()) {
            throw new InvalidConfigurationException('The node created by "services()" has already been initialized. You cannot pass values the second time you call services().');
        }

        return $this->services;
    }

    /**
     * @default {"query_max_depth":0,"query_max_complexity":0,"enable_introspection":true,"handle_cors":false}
    */
    public function security(array $value = []): \Symfony\Config\OverblogGraphql\SecurityConfig
    {
        if (null === $this->security) {
            $this->_usedProperties['security'] = true;
            $this->security = new \Symfony\Config\OverblogGraphql\SecurityConfig($value);
        } elseif (0 < \func_num_args()) {
            throw new InvalidConfigurationException('The node created by "security()" has already been initialized. You cannot pass values the second time you call security().');
        }

        return $this->security;
    }

    /**
     * @default {"types_mapping":[]}
    */
    public function doctrine(array $value = []): \Symfony\Config\OverblogGraphql\DoctrineConfig
    {
        if (null === $this->doctrine) {
            $this->_usedProperties['doctrine'] = true;
            $this->doctrine = new \Symfony\Config\OverblogGraphql\DoctrineConfig($value);
        } elseif (0 < \func_num_args()) {
            throw new InvalidConfigurationException('The node created by "doctrine()" has already been initialized. You cannot pass values the second time you call doctrine().');
        }

        return $this->doctrine;
    }

    /**
     * @default {"query_match":null}
    */
    public function profiler(array $value = []): \Symfony\Config\OverblogGraphql\ProfilerConfig
    {
        if (null === $this->profiler) {
            $this->_usedProperties['profiler'] = true;
            $this->profiler = new \Symfony\Config\OverblogGraphql\ProfilerConfig($value);
        } elseif (0 < \func_num_args()) {
            throw new InvalidConfigurationException('The node created by "profiler()" has already been initialized. You cannot pass values the second time you call profiler().');
        }

        return $this->profiler;
    }

    public function getExtensionAlias(): string
    {
        return 'overblog_graphql';
    }

    public function __construct(array $value = [])
    {
        if (array_key_exists('batching_method', $value)) {
            $this->_usedProperties['batchingMethod'] = true;
            $this->batchingMethod = $value['batching_method'];
            unset($value['batching_method']);
        }

        if (array_key_exists('definitions', $value)) {
            $this->_usedProperties['definitions'] = true;
            $this->definitions = new \Symfony\Config\OverblogGraphql\DefinitionsConfig($value['definitions']);
            unset($value['definitions']);
        }

        if (array_key_exists('errors_handler', $value)) {
            $this->_usedProperties['errorsHandler'] = true;
            $this->errorsHandler = new \Symfony\Config\OverblogGraphql\ErrorsHandlerConfig($value['errors_handler']);
            unset($value['errors_handler']);
        }

        if (array_key_exists('services', $value)) {
            $this->_usedProperties['services'] = true;
            $this->services = new \Symfony\Config\OverblogGraphql\ServicesConfig($value['services']);
            unset($value['services']);
        }

        if (array_key_exists('security', $value)) {
            $this->_usedProperties['security'] = true;
            $this->security = new \Symfony\Config\OverblogGraphql\SecurityConfig($value['security']);
            unset($value['security']);
        }

        if (array_key_exists('doctrine', $value)) {
            $this->_usedProperties['doctrine'] = true;
            $this->doctrine = new \Symfony\Config\OverblogGraphql\DoctrineConfig($value['doctrine']);
            unset($value['doctrine']);
        }

        if (array_key_exists('profiler', $value)) {
            $this->_usedProperties['profiler'] = true;
            $this->profiler = new \Symfony\Config\OverblogGraphql\ProfilerConfig($value['profiler']);
            unset($value['profiler']);
        }

        if ([] !== $value) {
            throw new InvalidConfigurationException(sprintf('The following keys are not supported by "%s": ', __CLASS__).implode(', ', array_keys($value)));
        }
    }

    public function toArray(): array
    {
        $output = [];
        if (isset($this->_usedProperties['batchingMethod'])) {
            $output['batching_method'] = $this->batchingMethod;
        }
        if (isset($this->_usedProperties['definitions'])) {
            $output['definitions'] = $this->definitions->toArray();
        }
        if (isset($this->_usedProperties['errorsHandler'])) {
            $output['errors_handler'] = $this->errorsHandler->toArray();
        }
        if (isset($this->_usedProperties['services'])) {
            $output['services'] = $this->services->toArray();
        }
        if (isset($this->_usedProperties['security'])) {
            $output['security'] = $this->security->toArray();
        }
        if (isset($this->_usedProperties['doctrine'])) {
            $output['doctrine'] = $this->doctrine->toArray();
        }
        if (isset($this->_usedProperties['profiler'])) {
            $output['profiler'] = $this->profiler->toArray();
        }

        return $output;
    }

}
